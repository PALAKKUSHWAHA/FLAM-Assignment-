# Real-Time Edge Detection Viewer

An Android app that captures camera frames, processes them using OpenCV in C++ (via JNI), and displays the processed output using OpenGL ES.

## Features Implemented

- [x] Camera feed integration using CameraX
- [x] Frame processing via OpenCV (C++) with Canny edge detection
- [x] OpenGL ES 2.0 rendering
- [x] JNI integration between Java and C++
- [x] Toggle between raw camera feed and edge-detected output

## Setup Instructions

1. Clone this repository
2. Open the project in Android Studio
3. Ensure you have the following installed:
   - Android NDK
   - OpenCV for Android (add to `app/src/main/jniLibs`)
4. Build and run the app

## Architecture Overview

1. **Camera Feed**: The app uses CameraX to capture frames from the device camera.
2. **JNI Bridge**: Frames are passed to native C++ code via JNI.
3. **OpenCV Processing**: The native code uses OpenCV to apply Canny edge detection.
4. **OpenGL Rendering**: Processed frames are rendered using OpenGL ES 2.0.

## Evaluation Criteria

- Native-C++ integration (JNI): Fully implemented
- OpenCV usage: Correct and efficient edge detection
- OpenGL rendering: Smooth real-time performance
- Project structure: Modular and clean
- Documentation: Complete README with setup instructions